package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mylayout);
        final TextView CalculatorScreen = findViewById(R.id.calculatorScreen);
        final Button n0 = findViewById(R.id.n0);
        final Button n1 = findViewById(R.id.n1);
        final Button n2 = findViewById(R.id.n2);
        final Button n3 = findViewById(R.id.n3);
        final Button n4 = findViewById(R.id.n4);
        final Button n5 = findViewById(R.id.n5);
        final Button n6 = findViewById(R.id.n6);
        final Button n7 = findViewById(R.id.n7);
        final Button n8 = findViewById(R.id.n8);
        final Button n9 = findViewById(R.id.n9);
        final Button punto = findViewById(R.id.punto);
        final Button igual = findViewById(R.id.igual);
        final Button suma = findViewById(R.id.suma);
        final Button resta = findViewById(R.id.resta);
        final Button division = findViewById(R.id.multi);
        final Button multi = findViewById(R.id.division);

        final View.OnClickListener calculatorListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int id = v.getId();
                switch (id){

                    case R.id.n0:
                    break;

                    case R.id.n1:
                        break;

                    case R.id.n2:
                        break;

                    case R.id.n3:
                        break;

                    case R.id.n4:
                        break;

                    case R.id.n5:
                        break;

                    case R.id.n6:
                        break;

                    case R.id.n7:
                        break;

                    case R.id.n8:
                        break;

                    case R.id.n9:
                        break;

                    case R.id.punto:
                        break;

                    case R.id.suma:
                        break;

                    case R.id.resta:
                        break;

                    case R.id.division:
                        break;

                    case R.id.multi:
                        break;

                    case R.id.igual:
                        break;
                }
            }
        };

        n0.setOnClickListener(calculatorListener);
        n1.setOnClickListener(calculatorListener);
        n2.setOnClickListener(calculatorListener);
        n3.setOnClickListener(calculatorListener);
        n4.setOnClickListener(calculatorListener);
        n5.setOnClickListener(calculatorListener);
        n6.setOnClickListener(calculatorListener);
        n7.setOnClickListener(calculatorListener);
        n8.setOnClickListener(calculatorListener);
        n9.setOnClickListener(calculatorListener);
        suma.setOnClickListener(calculatorListener);
        resta.setOnClickListener(calculatorListener);
        multi.setOnClickListener(calculatorListener);
        division.setOnClickListener(calculatorListener);
        punto.setOnClickListener(calculatorListener);
        igual.setOnClickListener(calculatorListener);

    }
}
